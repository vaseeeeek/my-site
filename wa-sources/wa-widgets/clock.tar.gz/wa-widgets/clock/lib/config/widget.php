<?php

return array(
    'name' => /*_w*/('Clock'),
    'size' => array('2x2', '2x1', '1x1'),
    'img' => 'img/clock.png',
    'version' => '1.3.1',
    'vendor' => 'webasyst',
);