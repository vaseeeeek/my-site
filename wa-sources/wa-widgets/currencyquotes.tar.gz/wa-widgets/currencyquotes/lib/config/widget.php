<?php
return array(
    'name' => /*_w*/('Currency quotes'),
    'size' => array('2x2', '2x1', '1x1'),
    'img' => 'img/currencyquotes.png',
    'locale' => 'ru_RU',
    'version' => '1.5.2',
    'vendor' => 'webasyst',
);