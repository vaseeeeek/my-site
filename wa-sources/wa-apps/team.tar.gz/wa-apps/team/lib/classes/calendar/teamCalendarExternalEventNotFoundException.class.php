<?php

class teamCalendarExternalEventNotFoundException extends waException
{
    protected $message = 'Event is not found';
}
