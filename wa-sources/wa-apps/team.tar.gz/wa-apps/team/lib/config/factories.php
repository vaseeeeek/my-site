<?php

return array(
    'front_controller' => 'teamFrontController'
);
