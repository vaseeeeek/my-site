<?php
return array(
    'name'       => 'Team',
    'icon'       => 'img/team.svg',
    'version'    => '2.1.1',
    'vendor'     => 'webasyst',
    'sash_color' => '#f0dc03',
    'system'     => true,
    'rights'     => true,
    'plugins'    => true,
    'csrf'       => true,
    'ui'         => '1.3,2.0'
);
