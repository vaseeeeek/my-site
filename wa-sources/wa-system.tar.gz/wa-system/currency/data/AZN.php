<?php

return array(
    'code' => 'AZN',
    'sign' => '₼',
	'iso4217' => '944',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Azerbaijani manat',
    'name' => array(
        array('manat', 'manats'),
    ),
    'frac_name' => array(
        array('qapik', 'qapiks'),
    )
);
