<?php

return array(
    'code' => 'KGS',
    'sign' => 'сом',
	'iso4217' => '417',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Kyrgyzstani som',
    'name' => array(
        'som',
    ),
    'frac_name' => array(
        'tyiyn',
    )
);