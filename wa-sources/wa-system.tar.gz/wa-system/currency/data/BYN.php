<?php

return array(
    'code' => 'BYN',
    'sign' => 'Br',
	'iso4217' => '933',
    'title' => 'Belarusian ruble',
    'name' => array(
        array('rouble', 'roubles'),
    ),
    'frac_name' => array(
        array('kopeck', 'kopecks'),
    )
);