<?php

return array(
    'code' => 'OMR',
    'sign' => 'rial',
	'iso4217' => '512',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Omani rial',
    'name' => array(
        array('rial', 'rials'),
    ),
    'frac_name' => array(
        'baisa',
    )
);