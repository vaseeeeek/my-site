<?php

return array(
    'code' => 'NGN',
    'sign' => '₦',
	'iso4217' => '566',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Nigerian naira',
    'name' => array(
        'naira',
    ),
    'frac_name' => array(
        'kobo',
    )
);