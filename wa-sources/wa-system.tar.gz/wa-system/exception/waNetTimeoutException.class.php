<?php

class waNetTimeoutException extends waNetException
{

}
