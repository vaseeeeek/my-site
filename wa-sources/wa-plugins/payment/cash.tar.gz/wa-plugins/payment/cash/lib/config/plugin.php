<?php
return array(
    'name' => /*_wp*/('Cash'),
    'description' => /*_wp*/('Pay in cash upon receipt'),
    'icon' => 'img/cash16.png',
    'logo' => 'img/cash.png',
    'vendor' => 'webasyst',
    'version' => '1.0.1',
    'type' => waPayment::TYPE_MANUAL,
);