<?php
return array(
    'currency'     => array(
        'value' => '',
    ),
    'payment_type' => array(
        'value' => array(),
    ),
    'weight_unit'         => array(
        'value' => 'kg',
    ),
    'length_unit'         => array(
        'value' => 'm',
    ),
    'service'             => array(
        'value' => ''
    ),
    'storage_days'        => array(
        'value' => '7',
    ),
    'country'             => array(
        'value' => '',
    ),
    'region'              => array(
        'value' => '',
    ),
    'city'                => array(
        'value' => '',
    ),
    'latitude'            => array(
        'value' => '',
    ),
    'longitude'           => array(
        'value' => '',
    ),
    'max_weight'          => array(
        'value' => '',
    ),
    'max_length'          => array(
        'value' => '',
    ),
    'max_width'           => array(
        'value' => '',
    ),
    'max_height'          => array(
        'value' => '',
    ),
    'free_shipping'       => array(
        'value' => '',
    ),
    'basic_shipping'      => array(
        'value' => '0',
    ),
    'markup_weight'       => array(
        'value' => '',
    ),
    'markup_weight_price' => array(
        'value' => '',
    ),
    'timezone'            => array(
        'value' => 'UTC'
    ),
    'weekend'             => array(
        'value' => array(),
    ),
    'workdays'            => array(
        'value' => array(),
    ),
    'additional'          => array(
        'value' => '',
    ),
    'way'                 => array(
        'value' => '',
    ),
);
